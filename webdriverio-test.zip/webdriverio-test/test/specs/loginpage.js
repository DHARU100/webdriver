describe('check for login and enter into the page',()=>{

it('Login to the page',()=>{
 browser.url('https://www.easyfundraising.org.uk/create-an-account');
 console.log('The page is loaded');
 const loginButton = $("//a[@id='create_an_account_login_link']");
 loginButton.click();
});

it ('Login in with valid Username',()=>{
  const userName = $("//input[@id='username']");
  userName.addValue("karthy.dharunya@gmail.com");

});

it ('Login in with valid Password',()=>{
    const password = $("//input[@id='password']");
    password.addValue("dharu1.DHARU");
  
  });
  
  it ('Click  submit to Login',()=>{
    const login = $("//button[@class='btn btn--md btn--full-width js-submit']");
    login.click();
  
  });
  

});
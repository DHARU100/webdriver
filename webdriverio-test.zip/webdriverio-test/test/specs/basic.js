describe('opeining a page',()=>{
 it('open the fundraising page',()=>{
    browser.url('https://www.easyfundraising.org.uk');
    console.log('The browser is opened')
    expect(browser).toHaveTitle('Fundraising | Charity Fundraising Online | You Spend Online, Brands Donate | Easyfundraising');
    console.log('The title matched')
 });
});
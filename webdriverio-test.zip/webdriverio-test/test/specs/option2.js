describe('Search for a cause',()=>{
    it('open the url for the search',()=>{
       browser.url('https://www.easyfundraising.org.uk/support-a-good-cause');
        console.log('browser open');
        expect(browser).toHaveTitle('Support a Good Cause | Easyfundraising');
    });
});
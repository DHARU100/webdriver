
import SearchPage from '../pageobjects/search.page';
describe('Search for a cause',()=>{
    it('open the url for the search',()=>{
       browser.url('https://www.easyfundraising.org.uk/support-a-good-cause');
        console.log('browser open');
        expect(browser).toHaveTitle('Support a Good Cause | Easyfundraising');
    });

   

    it('enter the value for search and search',()=>{
        SearchPage.searchValue.addValue('cancer');  //adding value to the element
        console.log('The search is activated');
        browser.pause(6000);
        SearchPage.sButton.click();   // Clicking the submit to search for the value added.
        
    });

});
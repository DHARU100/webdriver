import Page from "./page";

class SearchPage {

    
     
    get searchValue(){
        return $("//input['sagc-hero-search-input']"); // retuning the submit button xpath value
    }

    get sButton(){
        return $("//button[@id='sagc-hero-search-submit']"); // retuning the submit button xpath value

    }

   
} 
export default new SearchPage();
    
